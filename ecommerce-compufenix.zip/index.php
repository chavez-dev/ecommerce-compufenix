<?php

    header("location: frontend/php/login/login.php");

?>