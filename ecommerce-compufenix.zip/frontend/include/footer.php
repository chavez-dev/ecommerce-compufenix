</section>
    
    
    <!-- BOOTSTRAP JS -->
    <script src="../../../node_modules/bootstrap/dist/js/bootstrap.esm.min.js"></script>
    <!-- ALERTAS JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <!-- JQUERY -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- SIDEBAR JS -->
    <script src="../../js/admin/sidebar.js"></script>
    <!-- DATABLES JS -->
    <script src="//cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    <!-- <script src="../js/admin/empleado.js"></script> -->
    <!-- <script >

        $(document).ready(function() {
            $('#tablaUsuarios').DataTable( {
                ajax: {
                url: "../../../backend/consultas/lista_empleados.php",
                dataSrc: ""
                },
                columns: [
                { data: "id_empleado" },
                { data: "DNI" },
                { data: "id_rol" },
                { data: "id_contacto" },
                { data: "estado_actividad" }
                ] 
            });
        });
    </script> -->
</body>
</html>