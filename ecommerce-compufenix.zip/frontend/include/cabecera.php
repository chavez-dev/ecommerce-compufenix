<?php
	include("../../../backend/validacion/sesion_iniciada.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- STYLE CSS -->
    <link rel="stylesheet" href="../../css/admin/sidebar_nav.css">
    <!-- ICONOS FONTAWESOME-->
    <script src="https://kit.fontawesome.com/0324d3207d.js" crossorigin="anonymous"></script>
    <!-- USO DE DATATABLE -->
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="../../../scss/bootstrap.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>    