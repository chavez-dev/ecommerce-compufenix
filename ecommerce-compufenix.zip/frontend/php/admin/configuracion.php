<?php include("../../include/cabecera.php"); ?>
    
    <title>Configuraciones -Compufenix</title>
    <link rel="stylesheet" href="../../css/admin/configuracion.css">

<?php include("../../include/sidebar.php"); ?>


        <!-- CONTENIDO PRINCIPAL -->
        <main class="main-principal">
            CONFIGURACION
        </main>
        <!-- CONTENIDO PRINCIPAL -->

<?php include("../../include/footer.php"); ?>