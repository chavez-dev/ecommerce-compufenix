<?php include("../../include/cabecera.php"); ?>
    
    <title>Recibos - Compufenix</title>
    <link rel="stylesheet" href="../../css/admin/recibo.css">

<?php include("../../include/sidebar.php"); ?>


        <!-- CONTENIDO PRINCIPAL -->
        <main class="main-principal">
            RECIBO
        </main>
        <!-- CONTENIDO PRINCIPAL -->

<?php include("../../include/footer.php"); ?>