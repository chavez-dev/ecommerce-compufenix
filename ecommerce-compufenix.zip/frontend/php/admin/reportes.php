<?php include("../../include/cabecera.php"); ?>
    
    <title>Reportes -Compufenix</title>
    <link rel="stylesheet" href="../../css/admin/reportes.css">

<?php include("../../include/sidebar.php"); ?>


        <!-- CONTENIDO PRINCIPAL -->
        <main class="main-principal">
            REPORTES
        </main>
        <!-- CONTENIDO PRINCIPAL -->

<?php include("../../include/footer.php"); ?>