# Compufenix
El proyecto consiste en el desarrollo de un sistema de gestión integral para una tienda de venta y compra de equipos de cómputo. Esta aplicación estará diseñada para automatizar y optimizar todas las operaciones relacionadas con la gestión de inventario, ventas, compras y administración de la tienda.

WEB : 



